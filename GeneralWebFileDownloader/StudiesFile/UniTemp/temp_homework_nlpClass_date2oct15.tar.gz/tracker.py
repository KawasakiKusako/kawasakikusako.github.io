import requests
import time

headers ={
        'Accept': '*/*',
        'Accept-Encoding': 'gzip, deflate, br, zstd',
        'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6',
        'Content-Length': '53',
        'content-type': 'application/x-www-form-urlencoded',
        'Cookie': 'YOUR OWN COOKIE',
        'Origin': 'https://kaoyan.icourse163.org',
        'Referer': 'https://kaoyan.icourse163.org/course/terms/1463199445.htm?courseId=1003293003',# 请改成你的Referer
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36'  # 请改成你的浏览器信息
}


postURL = 'https://kaoyan.icourse163.org/web/j/kaoyanCourseBean.getCourseEvaluatePaginationByCourseId.rpc?csrfKey=d4bbb27d4838SS46ecbabb97322ddd4ff9' # 请改成你的课程

for i in range(1,3):  # 翻页1-30页，请改成自己的页码
	data = {"courseId":"1003293003", # 请改成你的课程id
	        "pageIndex":i,
	        "pageSize":20,
	        "orderBy":3}
	html = requests.post(postURL, data=data, headers=headers).text
	print(html)
	time.sleep(5) # 每循环一次的休息时间，怕被反爬

#整体输出到json

import json
with open('comments.json', 'w', encoding='utf-8') as f:
    json.dump(json.loads(html), f, ensure_ascii=False, indent=2)
