import pandas as pd
import jieba
import os

csv_file_path = 'mooccomment.csv'
stop_words_path = 'stop.txt'
output_file_path = 'segmented_comments.csv'  # 可选：保存分词结果的文件路径
import time
start_time = time.time()

def load_stop_words(stop_words_file):
    """加载停用词表"""
    stop_words = set()
    try:
        with open(stop_words_file, 'r', encoding='utf-8') as f:
            for line in f:
                stop_word = line.strip()
                if stop_word:  # 跳过空行
                    stop_words.add(stop_word)
        print(f"成功加载停用词表，共{len(stop_words)}个停用词")
    except Exception as e:
        print(f"加载停用词表时出错: {e}")
    return stop_words

def segment_text(text, stop_words):
    
    global segment_time
    segment_time = time.time()

    """对文本进行分词并去除停用词"""
    if pd.isna(text) or not isinstance(text, str):
        return []
    
    words = jieba.lcut(text)
    
    filtered_words = [word for word in words if word.strip() and word not in stop_words]

    
    return filtered_words 

def main():
    if not os.path.exists(csv_file_path):
        print(f"错误：找不到文件 {csv_file_path}")
        return
    
    # 检查停用词文件是否存在
    if not os.path.exists(stop_words_path):
        print(f"错误：找不到文件 {stop_words_path}")
        return
    
    try:
        df = pd.read_csv(csv_file_path)
        print(f"成功读取CSV文件，共{len(df)}条评论")
        if 'content' not in df.columns:
            print("错误：CSV文件中不包含content列")
            return
        stop_words = load_stop_words(stop_words_path)
        #示例
        print("开始进行分词和去停用词处理...")
        df['segmented_content'] = df['content'].apply(lambda x: segment_text(x, stop_words))
        for i, row in df.head(5).iterrows():
            print(f"原始评论 {i+1}: {row['content']}")
            print(f"分词结果 {i+1}: {' '.join(row['segmented_content'])}")
            print("---")

        #保存时按照csv格式，且首列为分词出来对应源mooccomment.csv的id列
        df[['id', 'segmented_content']].to_csv(output_file_path, index=False, encoding='utf-8')
        print(f"分词结果已保存到 {output_file_path}")

        
        total_words = sum(len(words) for words in df['segmented_content'])
        unique_words = set(word for words in df['segmented_content'] for word in words)
        print(f"\n分词统计信息：")
        print(f"总词数：{total_words}")
        print(f"不同词的数量：{len(unique_words)}")
        

        print(f"分词处理完成，项目总花费时间：{time.time() - start_time:.2f}秒")
        print(f'分词处理完成，分词环节总花费时间:{time.time() - segment_time:.2f}秒')
        #print(f"每个评论的平均分词时间：{sum(df['segmented_content'].apply(lambda x: x[1])) / len(df):.4f}秒")
        
    except Exception as e:
        print(f"处理过程中出错: {e}")

if __name__ == "__main__":
    main()