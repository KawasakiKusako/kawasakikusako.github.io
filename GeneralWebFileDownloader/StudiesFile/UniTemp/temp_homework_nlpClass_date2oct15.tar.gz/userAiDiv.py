import pandas as pd
import jieba
import os
import time
import zhipuai as zpai
from functools import lru_cache

csv_file_path = 'mooccomment.csv'
output_file_path = 'segmented_ai_comments.csv'

def set_api_key():
    """设置zhipuai API密钥（请用户根据实际情况设置）"""
    try:
        zpai.api_key = "YOUR API"
        if not hasattr(zpai, 'api_key') or not zpai.api_key:
            print("警告：zhipuai API密钥未设置，请在代码中设置zpai.api_key = '您的API密钥'")
            return False
        return True
    except Exception as e:
        print(f"设置API密钥时出错: {e}")
        return False

@lru_cache(maxsize=10000)  # 缓存API调用结果，避免重复调用
def is_stop_word_ai(word):
    """使用AI API判断是否为停用词"""
    if not word or len(word) <= 1:  
        return True
    
    try:
        response = zpai.chat.completions.create(
            model="glm-4",
            messages=[
                {"role": "system", "content": "你是专业的中文文本处理助手，核心任务是精准判断单个给定词语是否为停用词，需严格遵循以下规则：1. 停用词定义：指在中文文本中高频出现、无独立实质语义、对文本核心含义贡献极小的词，包含但不限于：- 助词：的、地、得、了、着、过、呢、吗、啊、吧 - 介词：在、从、到、对、把、被、为、因、由 - 连词：和、与、及、或、但、而、若、因、所以 - 数词 / 量词：一、二、三、个、只、本、件、次（单用时，如 “一”“个”；组合词如 “一个”“三次” 需结合场景，若无特殊语义也归为停用词）- 代词：我、你、他、她、它、这、那、此、其、我们、你们 - 其他无实义高频词：就、都、很、也、还、要、会、有、没、不 2. 判断原则：优先看词语是否符合上述类别，若属于则判为停用词；若词语有明确实义（如名词 “课程”“学生”、动词 “学习”“讨论”、形容词 “优质”“困难”），即使高频也不判为停用词。3. 输出要求：仅返回 “是” 或 “否”，不附加任何额外解释、标点或文字。"},
                {"role": "user", "content": f"判断'{word}'是否为停用词"}
            ],
            temperature=0.0
        )
        
        # 解析API响应
        result = response.choices[0].message.content.strip()
        return result == "是"
    except Exception as e:
        print(f"API调用失败: {e}")
        # 这些规则可以根据实际情况调整
        stop_word_patterns = {'的', '了', '在', '是', '我', '有', '和', '就', '不', '人', '都', '一', '一个', '上', '也', '很', '到', '说', '要', '去', '你', '会', '着', '没有', '看', '好', '自己', '这'}
        return word in stop_word_patterns

def segment_text_ai(text):
    """对文本进行分词并使用AI去除停用词"""
    if pd.isna(text) or not isinstance(text, str):
        return []
    words = jieba.lcut(text)
    
    # 使用AI判断并去除停用词和空白字符
    filtered_words = []
    for word in words:
        if word.strip() and not is_stop_word_ai(word):
            filtered_words.append(word)
            if len(filtered_words) % 10 == 0:
                print(f"  已处理{len(filtered_words)}个有效词...", end='\r')
    
    return filtered_words

def main():
    start_time = time.time()
    
    if not set_api_key():
        print("api error")
        return
    if not os.path.exists(csv_file_path):
        print(f"错误：找不到文件 {csv_file_path}")
        return
    
    try:
        df = pd.read_csv(csv_file_path)
        print(f"共{len(df)}条评论")
        if 'content' not in df.columns:
            print("错误：CSV文件中不包含content列")
            return
        
        sample_size = min(50, len(df))  # 仅处理前x条评论

        #sample_size = min(len(df), len(df))   # 处理全部
        
        sample_df = df.head(sample_size).copy()
        sample_df['segmented_content'] = ''
        
        # 逐条处理并显示进度
        for i, row in sample_df.iterrows():
            print(f"处理评论 {i+1}/{sample_size}: {row['content'][:30]}...")
            sample_df.at[i, 'segmented_content'] = segment_text_ai(row['content'])
            print(f"  完成，保留了{len(sample_df.at[i, 'segmented_content'])}个词")
        
        # 打印处理结果作为示例
        print("\nAI分词结果示例：")
        for i, row in sample_df.iterrows():
            print(f"原始评论 {i+1}: {row['content']}")
            print(f"AI分词结果 {i+1}: {' '.join(row['segmented_content'])}")
            print("---")
        
        #保存时按照csv格式，且首列为分词出来对应源mooccomment.csv的id列
        sample_df[['id', 'segmented_content']].to_csv(output_file_path, index=False, encoding='utf-8')
        print(f"AI分词结果已保存到 {output_file_path}")
        
        # stastic info
        total_words = sum(len(words) for words in sample_df['segmented_content'])
        unique_words = set(word for words in sample_df['segmented_content'] for word in words)
        print(f"\nAI分词统计信息：")
        print(f"总词数：{total_words}")
        print(f"不同词的数量：{len(unique_words)}")
        
        print(f"\n处理完成，总花费时间：{time.time() - start_time:.2f}秒")
        print("\n注意：")
    except Exception as e:
        print(f"处理过程中出错: {e}")

if __name__ == "__main__":
    main()