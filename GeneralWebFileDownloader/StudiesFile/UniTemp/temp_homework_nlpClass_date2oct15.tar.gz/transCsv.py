import json
import csv
import os

# 定义要处理的文件路径
JSON_FILE = 'comments.json'
CSV_FILE = 'mooccomment.csv'

# 定义CSV文件的字段名
FIELDS = ['id', 'gmtModified', 'userNickName', 'content', 'mark', 'agreeCount']

# 检查JSON文件是否存在
if not os.path.exists(JSON_FILE):
    print(f"错误: {JSON_FILE} 文件不存在")
    exit(1)

try:
    # 读取JSON文件
    with open(JSON_FILE, 'r', encoding='utf-8') as f:
        try:
            data = json.load(f)
        except json.JSONDecodeError:
            print(f"错误: {JSON_FILE} 文件格式不正确，不是有效的JSON格式")
            exit(1)
    
    # 检查数据结构（根据之前查看的实际结构）
    if isinstance(data, dict) and 'result' in data and 'list' in data['result']:
        # 如果数据结构是{"result": {"list": [...]}}，则使用这个路径
        items = data['result']['list']
    else:
        # 否则假设data已经是列表或者可以迭代的对象
        items = data
    
    # 写入CSV文件
    with open(CSV_FILE, 'w', encoding='utf-8', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=FIELDS)
        writer.writeheader()
        
        count = 0
        for item in items:
            # 使用字典推导式创建要写入的行，自动处理缺失的字段
            row = {field: item.get(field, '') for field in FIELDS}
            writer.writerow(row)
            count += 1
    
    print(f"成功: 已将{count}条记录从{JSON_FILE}导出到{CSV_FILE}")
    
# 处理其他可能的异常
except Exception as e:
    print(f"发生错误: {str(e)}")
    exit(1)

#再次读取mooccomment.csv文件
import pandas as pd
df = pd.read_csv('mooccomment.csv')
df.head()

#把回车全部处理成空格
df['content'] = df['content'].str.replace('\n', ' ')
df.head()

#写回mooccomment.csv文件
df.to_csv('mooccomment.csv', index=False, encoding='utf-8')
