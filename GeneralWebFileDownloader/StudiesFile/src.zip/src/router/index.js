//引入核心文件
import { resolveDirective } from "vue";
import { createRouter,createWebHashHistory } from "vue-router";
//2.配置路由数组
let route = [
    {
        path:"/",
        redirect: "/index"
    },
    {
        path: "/index",
        component: ()=> import("@/page/index/index.vue")
    },
    {
        path: '/:pathMatch(.*)',//容错页
        component: ()=> import("@/page/error/index.vue")
    },
    {
        path: "/maps",
        component: ()=> import("@/page/maps/index.vue")
    },
    {
        path: "/new1",
        component: ()=> import("@/page/new1/1.vue")
    },
    {
        path: "/new2",
        component: ()=> import("@/page/new2/2.vue")
    },
    {
        path: "/new3",
        component: ()=> import("@/page/new3/3.vue")
    }
]
    

let router = createRouter({
    routes: route,//路由数组
    history: createWebHashHistory() //hash模式
})

//3.暴露给外部使用
export default router;