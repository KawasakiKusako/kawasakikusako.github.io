<template>
    <div class="mainBox">
        <div class="box1">
            <img src="@/assets/logo.png"/>
        </div>
        <div class="menu">           
            <div class="caidan">
                <a href="#/index">
                    <img class="index" src="@/assets/shouye.png" alt="1"/>
                </a>
                <a href="#/maps">
                    <img class="index2" src="@/assets/ditu.png" alt="2"/>
                </a>
            </div>
        </div>
    </div>
</template>

<script setup>

</script>

<style lang="scss" scoped>
.mainBox{
  width: 100%;
  height: 300px;
  .box1{
    width: 450px;
    height: 144px;
    margin:auto;
  }
  .menu{
        width: 100%;
        height: 125px;
        display: flex;
        .caidan{
            width: 1000px;
            height: 100%;
            margin: auto;
            // -webkit-clip-path: polygon(50% 0%, 91% 0, 91% 100%, 50% 100%, 0 100%, 0 1%);
            // clip-path: polygon(50% 0%, 91% 0, 91% 100%, 50% 100%, 0 100%, 0 1%);
            background-image: url('@/assets/menu1.png');
            background-size: cover;
            .index{
                height: 100%;
                margin-left: 81px;
                opacity: 0.0;
                transition: all 0.5s;
                &:hover{
                    opacity: 1.0;
                    filter: brightness(1.1);
                }
            }
            .index2{
                height: 100%;
                margin-left:484px;
                opacity: 0.0;
                transition: all 0.5s;
                &:hover{
                    opacity: 1.0;
                    filter: brightness(1.1);
                }
            }
        }
    }
}

</style>