<template>
    <div class="footer">
        <div class="left">
            ©2021 Re-Logic. All rights reserved |
        </div>
        <div class="right shou"> 
            Legal |
        </div>
        <div class="right shou"> 
            PC Dedicated Server |
        </div>
        <div class="right shou"> 
            Mobile Dedicated Server |
        </div>
        <div class="right shou"> 
            About Us
        </div>
    </div>
</template>

<script setup>

</script>

<style lang="scss" scoped>
.footer{
    width: 100%;
    height: 30px;
    background: rgba($color: #000000, $alpha: 0.3);
    display: flex;
    justify-content: center;
    align-items: center;
}
.left{
    color: white;
    margin-right: 5px;
}
.right{
    color: rgb(187, 187, 255);
    margin-left: 5px;
}
.shou{
    cursor: pointer;
    &:hover{
        text-decoration: underline;
    }
}
</style>