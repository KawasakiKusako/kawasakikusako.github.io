<template>
    <div class="bigbox">
        <div class="grass">
            <img src="@/assets/wallTop.png" />
        </div>
        <div class="title" style="margin-top: -5px;"> 
            <div class="titlebox1">
                <div class="titletext">
                    <strong>泰拉瑞亚 x 饥荒一起更新现已推出！</strong>
                </div>
            </div>
        </div>
        <div class="middle">
            <div class="img"><img src="@/assets/new3-1.png" width="870px"/></div>
            <div class="middletext">泰拉瑞亚玩家们，大家好，欢迎来到永恒领域！</div>
            <div class="middletext">正如我们在短短几周前透露的那样，我们一直在与 Klei Entertainment 的好朋友秘密努力工作，以便为泰拉瑞亚和饥荒的粉丝带来全新的免费内容更新，忠实地将每个游戏的一部分拉入另一个游戏。这一切将如何运作？我们究竟为我们的跨界车准备了什么？勇敢的泰拉瑞亚人勇往直前，了解更多关于 The Constant 与泰拉瑞亚世界碰撞时等待你的是什么！</div>
            <div class="img"><img src="@/assets/divid-0x5fcb50a4aec00000.png" /></div>
            <div class="middletext">永恒领域 - 受 DON'T STARVE 启发的世界种子</div>
            <div class="middletext">团队就以有趣和巧妙的方式将 Don't Starve Together 的游戏动态引入泰拉瑞亚的最佳方式进行了长时间而激烈的辩论。我们决定利用 Journey's End 中的世界种子功能来创造更全面的 Don't Starve x Terraria 体验，而不是像我们在 Dungeon Defenders 2 中所做的那样拥有一个独立的“活动”。如果您敢于探索 The Constant ，等待您的是什么？</div>
            <div class="img"><img src="@/assets/new3-2.jpg" width="870px" height="400px"/></div>
            <div class="middletext">饥荒 Inspired 着色器和照明</div>
            <div class="img"><img src="@/assets/new3-3.gif" width=870; height=150;/></div>
            <div class="middletext">待在光明中！完全的黑暗对您的健康有害！</div>
            <div class="img"><img src="@/assets/new3-4.gif" /></div>
            <div class="middletext">用美味的食物来满足你的饥饿感......或面对后果！</div>
            <div class="middletext">饥荒启发 Worldgen</div>
            <div class="middletext">饥荒启发物品的掉落率更高</div>
            <div class="middletext">要探索这种玩泰拉瑞亚的新方式，饥荒齐心，只需在创建新世界时输入“The Constant”作为你的世界种子。祝你好运，泰拉玩家！</div>
        </div>
        <div class="title" style="margin-top: -5px;"> 
            <div class="titlebox2">
                <div class="bottomtext">
                    <i>最后更新日期： 2025/05/15</i>
                </div>
            </div>
        </div>
    </div>
</template>

<script setup>

</script>

<style lang="scss" scoped>
.bigbox{
    width: 970px;
    margin: auto;
    display: flex;
    justify-content: center;
    flex-direction: column;
    .title{
        display: flex;
        justify-content: center;
        flex-direction: column;
        background-image: url('@/assets/title.jpg');
        background-size: cover;
        background-repeat: no-repeat;
        background-position: center;
        .titlebox1{
            color:#d6ffe4;
            font-size: 26px;
            border-bottom: 1.5px solid burlywood;
            .titletext{
                margin-left:30px ;
            }
        }
            
    }
    .middle{
        width: 970px;
        height: 1900px;
        display: flex;
        justify-content: center;
        flex-direction: column;
        background-image: url('@/assets/middle.jpg');
        background-size: cover;
        background-repeat: no-repeat;
        background-position: center;
        .middletext{
            margin-left:50px ;
            color: #f6ffe3;
            margin-bottom:20px ;
            font-size: 20px;
        }
        .img{
            display: flex;
            justify-content: center;
            align-items: center;
        }
    }
    .titlebox2{
        border-top: 1.5px solid burlywood;
        .bottomtext{
                font-size: 20px;
                color:#d6ffe4;
                margin: 10px;
                margin: left 20px; ;
            }
    }
}
</style>