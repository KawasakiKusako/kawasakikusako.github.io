<template>
    <div class="erro">
        <div class="bigBox">
            <div class="top"></div>
            <div class="btm">
                <div class="cuowu">ERROR</div>
                <img style="margin-left: 475px; width: 200px;" src="@/assets/walk.gif"/>
                <div class="text">
                    你进入了不存在的迷失之地...返回<a class="lianjie" href="/index.html">首页</a>
                </div>            
            </div>
        </div>
    </div>
</template>

<script setup>

</script>

<style lang="scss" scoped>
.erro{
    width: 100%;
    height: 800px;
    justify-content: center;
    padding: 200px 0px;
    .bigBox{
        width: 1200px;
        height: 1000px;
        margin: auto;
    }
    .top{
        width: 100%;
        height: 10px;
        margin: auto;
        margin-top: 0px;
        margin-bottom: -1px;
        background-image: url("@/assets/Grass-top.png");
    }
    .btm{
        width: 100%;
        height: 800px;
        margin-top: 0px;
        background-image: url("@/assets/Content-background.jpg");
        color: #eae3d1;
        .text{
            width: 400px;
            height: auto;
            margin: auto;
            font-size: 20px;
        }
        .cuowu{
            width: 100%;
            height: 40px;
            font-size: 20px;
            margin-left: 20px;
            border-bottom: 1px solid black;
        }
    }
}
.lianjie{
    color: #a7eef1;
    text-decoration: none;
}
</style>