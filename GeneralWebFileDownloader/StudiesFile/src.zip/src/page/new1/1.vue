<template>
    <div class="bigbox">
        <div class="grass">
            <img src="@/assets/wallTop.png" />
        </div>
        <div class="title" style="margin-top: -5px;"> 
            <div class="titlebox1">
                <div class="titletext">
                    <strong>泰拉瑞亚：爱之劳动现已推出!</strong>
                </div>
            </div>
        </div>
        <div class="middle">
            <div class="middletext">发布日快乐，泰拉悠闲人!</div>
            <div class="img"><img src="@/assets/Y.1.png" /></div>
            <div class="middletext">泰拉瑞亚：爱之劳动来了!!</div>
            <div class="middletext">我们在下面的官方更新日志帖子中为您提供了所有详细信息（或只需单击上面的横幅图片）。</div>
            <div class="middletext">泰拉瑞亚：爱之劳动 更新日志</div>
            <div class="middletext">我们感谢你们每一位，我们想在下面分享一封团队写给你们的小情书——非常感谢你们多年来对我们的支持......还有更多内容!!</div>
            <div class="img"><img src="@/assets/A Terrarian Love Letter 4.png" width=870; height=480;/></div>
        </div>
        <div class="title" style="margin-top: -5px;"> 
            <div class="titlebox2">
                <div class="bottomtext">
                    <i>最后更新日期： 2022/9/27 下午11：38：45</i>
                </div>
            </div>
        </div>
    </div>
</template>

<script setup>

</script>

<style lang="scss" scoped>
.bigbox{
    width: 970px;
    margin: auto;
    display: flex;
    justify-content: center;
    flex-direction: column;
    .title{
        display: flex;
        justify-content: center;
        flex-direction: column;
        background-image: url('@/assets/title.jpg');
        background-size: cover;
        background-repeat: no-repeat;
        background-position: center;
        .titlebox1{
            color:#d6ffe4;
            font-size: 26px;
            border-bottom: 1.5px solid burlywood;
            .titletext{
                margin-left:30px ;
            }
        }
            
    }
    .middle{
        width: 970px;
        height: 1300px;
        display: flex;
        justify-content: center;
        flex-direction: column;
        background-image: url('@/assets/middle.jpg');
        background-size: cover;
        background-repeat: no-repeat;
        background-position: center;
        .middletext{
            margin-left:50px ;
            color: #f6ffe3;
            margin-bottom:20px ;
            font-size: 20px;
        }
        .img{
            display: flex;
            justify-content: center;
            align-items: center;
        }
    }
    .titlebox2{
        border-top: 1.5px solid burlywood;
        .bottomtext{
                font-size: 20px;
                color:#d6ffe4;
                margin: 10px;
                margin: left 20px; ;
            }
    }
}
</style>