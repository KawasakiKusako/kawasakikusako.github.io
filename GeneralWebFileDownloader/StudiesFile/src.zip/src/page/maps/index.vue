<template>
    <div class="gTitle">
        <div class="gTitleLeft">
            <div class="mainT"><img class="tLogo" src="@/assets/logo.png"/>大地图<a class="grltBeta">Beta</a><a class="grltBeta">@kawasaki</a></div>
            <!--Kawasaki-->
            <div class="subT">游戏攻略/boss信息</div>
        </div>
            <div class="tLink"><img  class="tLogo" src="@/assets/favicon.ico"/><a class="tRef" href="https://terramap.github.io/#">地图生成器</a></div>
    </div>
    <div class="topWall"></div>
    <div class="mainBox">
        <div class="gMap">
            <!--
            <div class="topWall" style="margin-bottom: 7px;"></div>
            -->
            <div class="gmMain"> 
                <!--
                <img class="gmmImg" src="@/assets/main.png"/>
                -->
                <div class="gmmBoss">
                    <!--
                    <div class="gmmb roushan" tabindex="1">
                        <button class="bossImg" onclick="butAct(this)"><img class="bossImgIn" src="@/assets/roushan.png"/><div class="gmmbTips">血肉山<span class="gmmbTipsText">血肉墙是困难模式之前最终且最强的 Boss<a class="gmmbtRef" href="http://www.nmc.cn">查看攻略</a></span></div></button>
                    </div>
                    <div class="shijuren" tabindex="1">
                        <button class="bossImg" onclick="butAct(this)"><img class="bossImgIn" src="@/assets/roushan.png"/><div class="gmmbTips">石巨人<span class="gmmbTipsText">血肉墙是困难模式之前最终且最强的 Boss<a class="gmmbtRef" href="http://www.nmc.cn">查看攻略</a></span></div></button>
                    </div>
                    -->
                    <div class="gmmb" v-for="item in gmmbArr" :key = "item.id" @click="changeGtiFn(item)">
                        <div class="gmmbSub" :style="item.position" tabindex="1">
                            <button class="bossImg" onclick="butAct(this)">
                                <img class="bossImgIn" :src="item.icon"/>
                                <div class="gmmbTips">{{item.title}}
                                    <span class="gmmbTipsText">{{ item.tips }}
                                        <a class="gmmbtRef" :href="item.ref">
                                            查看攻略
                                        </a>
                                    </span>
                                </div>
                            </button>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <div class="gInfo">
            <div class="gibTop">
                <div class="gibTopTop">
                    <div class="gttTitle">
                        <div class="gtttText">{{ gttibObj.title }}</div>
                        <div class="gtttIcon"><img class="gtttiImg" :src="gttibObj.img"/></div>
                        <div class="gtttQuation">{{ gttibObj.quation }} </div>
                        <div class="gtttBasicInfo">{{ gttibObj.basicinfo}}</div>
                    </div>
                    <div class="gttInfo">
                        <div class="gttiBox">
                            <div class="gttibTitle"></div>
                            <div class="gttibText">
                                <div class="gtiSub">
                                    <div class="stastic">类型</div>
                                    <div class="dynamic">{{ gttibObj.type }}</div>
                                </div>
                                <div class="gtiSub">
                                    <div class="stastic">环境</div>
                                    <div class="dynamic">{{gttibObj.envir}}</div>
                                </div>
                                <div class="gtiSub">
                                    <div class="stastic">AI类型</div>
                                    <div class="dynamic">{{gttibObj.ai}}</div>
                                </div>
                                <div class="gtiSub">
                                    <div class="stastic">伤害</div>
                                    <div class="dynamic">{{ gttibObj.damage }}</div>
                                </div>
                                <div class="gtiSub">
                                    <div class="stastic">最大生命值</div>
                                    <div class="dynamic">{{gttibObj.maxhp}}</div>
                                </div>
                                <div class="gtiSub">
                                    <div class="stastic">防御/击退抗性</div>
                                    <div class="dynamic">{{gttibObj.resist}}</div>
                                </div>
                            </div>
                            <div class="gttibImg"></div>
                        </div>
                    </div>
                    <div class="gttLink">
                        <div class="gttlIcon">
                            <img  class="tLogo" src="@/assets/favicon.ico" href="https://terraria.wiki.gg/zh/wiki/"/>
                        </div>
                        <div class="gttlText">
                            <a class="gttltRef" href="https://terraria.wiki.gg/zh/wiki/">打开百科首页</a>
                        </div>
                    </div>
                    
                </div>
                <div class="gibTopBot"></div>
            </div>
            
            
            <div class="gibBot">
                <div class="topWall"></div>
                <div class="gibbBox">
                    <a class="gibbba" href="https://www.bilibili.com/video/BV1eec4ebELY/">
                        <img class="gibbbVideo" src="@/assets/videoCover.jpg" alt="VideoCover" />
                    </a>
                </div>
            </div>
        </div>
    </div>
    <div class="gClick">
        <div class="topWall"></div>
        <div class="gckBox">
            もっともっと,查看更多
        </div>
    </div>
    <div class="wikiFrame">
        <div>
            <iframe class="wiframe" :src="gttibObj.ref"></iframe>
        </div>
    </div>
</template>

<script setup>
//import

import { ref,reactive } from 'vue';

//function
function butAct(element) {
  element.classList.toggle("active");
}

console.log("kawasaki")

//arr
let gmmbArrIn = reactive([
  
])

let gmmbArr = reactive([
{icon:'https://terraria.wiki.gg/images/3/3f/Wall_of_Flesh_Eye.gif',title:'血肉山',tips:'血肉墙是困难模式前最终且最强的boss',ref:'https://terraria.wiki.gg/zh/wiki/%E8%A1%80%E8%82%89%E5%A2%99',position:'top: 650px;left: 100px;',img:'https://terraria.wiki.gg/images/c/c0/Wall_of_Flesh.gif?b39287',quation:'“世界的主宰与核心。”',basicinfo:'只能在地狱中生成。一旦它被打败，世界永久性转化为困难模式，带来新的内容和挑战。',type:'BOSS',envir:'地狱',ai:'血肉墙AI',damage:'50',maxhp:'8000',resist:'12/100%'},
{icon:'https://terraria.wiki.gg/images/9/93/King_Slime.gif',title:'史莱姆王',tips:'血肉墙是困难模式前最终且最强的boss',ref:'https://terraria.wiki.gg/zh/wiki/%E5%8F%B2%E8%8E%B1%E5%A7%86%E7%8E%8B',position:'top: 100px;left: 300px;',img:'https://terraria.wiki.gg/images/9/93/King_Slime.gif',quation:'所有黏滑生物的首领。”',basicinfo:'史莱姆王是个困难模式之前的 Boss。其外观是戴着珠宝金冠的巨大蓝史莱姆，内部似乎还有个忍者。',type:'BOSS 史莱姆',envir:'森林 史莱姆雨',ai:'史莱姆王AI',damage:'40',maxhp:'2000',resist:'10/100%'},
{icon:'https://terraria.wiki.gg/images/thumb/6/68/Eye_of_Cthulhu.gif/170px-Eye_of_Cthulhu.gif?a93ed2',title:'克苏鲁之眼',tips:'我希望在我们和克苏鲁之眼的对抗中，不只有你这么个瘦弱的孩子保护我们。',ref:'https://terraria.wiki.gg/zh/wiki/%E5%85%8B%E8%8B%8F%E9%B2%81%E4%B9%8B%E7%9C%BC',position:'top: 120px;left: 450px;',img:'https://terraria.wiki.gg/images/7/79/Eye_of_Cthulhu_%28Phase_2%29.gif',quation:'“只在夜间出没的危险眼球怪。”',basicinfo:'克苏鲁之眼是一个困难模式之前的 Boss。它通常是玩家在游戏中会遇到的第一个 Boss 之一',type:'BOSS',envir:'地表/太空+夜晚',ai:'克苏鲁之眼AI',damage:'15',maxhp:'3900',resist:'12/100%'},
{icon:'https://terraria.wiki.gg/images/0/0f/Eater_of_Worlds_Head.png?e0e60b',title:'世界吞噬怪',tips:'血肉墙是困难模式前最终且最强的boss',ref:'https://terraria.wiki.gg/zh/wiki/%E4%B8%96%E7%95%8C%E5%90%9E%E5%99%AC%E6%80%AA',position:'top: 350px;left: 850px;',img:'https://terraria.wiki.gg/images/0/0f/Eater_of_Worlds_Head.png?e0e60b',quation:'“居住在腐化之地的巨虫。”',basicinfo:'世界吞噬怪是一个困难模式之前，腐化主题的蠕虫 Boss。',type:'BOSS 钻地怪敌',envir:'腐化之地',ai:'蠕虫AI',damage:'N/A',maxhp:'15120',resist:'null/100%'},
{icon:'https://terraria.wiki.gg/images/thumb/6/6a/Brain_of_Cthulhu.gif/170px-Brain_of_Cthulhu.gif?e4bca6',title:'克苏鲁之脑',tips:'打败克苏鲁之脑及其伴随的飞眼怪是唯一能得到组织样本的方法',ref:'https://terraria.wiki.gg/zh/wiki/%E5%85%8B%E8%8B%8F%E9%B2%81%E4%B9%8B%E8%84%91',position:'top: 300px;left: 1000px;',img:'https://terraria.wiki.gg/images/0/03/Brain_of_Cthulhu_%28Second_Phase%29.gif',quation:'“出没在让人毛骨悚然的猩红之地的巨大恶魔大脑。”',basicinfo:'克苏鲁之脑是困难模式之前的猩红主题的 Boss，像是一个巨大的飞行大脑。',type:'BOSS',envir:'（地下）猩红之地',ai:'克苏鲁之脑AI',damage:'30',maxhp:'1250（不计飞眼怪）',resist:'14/55%（PC)'},
{icon:'https://terraria.wiki.gg/images/6/60/Queen_Bee.gif',title:'蜂王',tips:'蜂王有三种不同的攻击模式',ref:'https://terraria.wiki.gg/zh/wiki/%E8%9C%82%E7%8E%8B',position:'top: 450px;left: 300px;',img:'https://terraria.wiki.gg/images/3/34/Queen_Bee_%28old%29.gif?590456',quation:'“统治丛林蜂巢的女王。”',basicinfo:'蜂王是一个困难模式之前的 Boss。召唤她需要在地下丛林破坏幼虫，也可以在丛林使用憎恶之蜂召唤。',type:'BOSS',envir:'蜂巢/（地下）丛林',ai:'蜂王AI',damage:'30/22',maxhp:'3400',resist:'8/100%'},
{icon:'https://terraria.wiki.gg/images/a/a3/Skeletron_Head.png',title:'骷髅王',tips:'不要与骷髅，可在地下发现的敌怪，或是机械骷髅王，骷髅王的困难模式版本相混淆。',ref:'https://terraria.wiki.gg/zh/wiki/%E9%AA%B7%E9%AB%85%E7%8E%8B',position:'top: 150px;left: 800px;',img:'https://terraria.wiki.gg/images/thumb/e/ea/Skeletron.png/170px-Skeletron.png?f8e531',quation:'“它是被诅咒的地牢守卫。”',basicinfo:'玩家在进入地牢之前必须击败骷髅王，击败骷髅王可以让所有玩家在该世界获得任意进出地牢区域的权限。',type:'BOSS',envir:'夜晚地牢入口',ai:'骷髅王AI',damage:'32/1000(白天)',maxhp:'4400/10',resist:'0(旋转时);9999/100%'},

])


let gttibObj = ref({
    title:'',
    img:'https://32comic.com/wp-content/uploads/2021/09/wxsync-2021-09-973ba3240cb4d022a9137b047020b0a4.gif',
    ref:'https://terraria.wiki.gg/zh/wiki',
    quation:'欢迎使用大地图！',
    basicinfo:'《泰拉瑞亚》是冒险之地！是神秘之地！是可让你塑造、捍卫、享受的大地。在《泰拉瑞亚》，你有无穷选择。手指发痒的动作游戏迷？建筑大师？收藏家？探险家？每个人都能找到自己想要的。',
    type:'',
    envir:'',
    ai:'',
    damage:'',
    maxhp:'',
    resist:''
  
})

//初始值
let gttibName = ref('血肉山1');
//点击Table标题的函数，使得当前点击的对象赋值给tabObj，使得视图自动更新；
function changeGtiFn(v){
    gttibObj.value = v;
    //click时：把标题赋值给定义好的变量tabName的初始值
    gttibName.value = v.title;
}
//var

//oth

</script>

<style lang="scss" scoped>
.topBox{
    padding: 50px 0; 
}
.gTitle{
       margin-left: 30px;
       margin-bottom: 20px;
       /*width: 100%;*/
       height:70px;
       display: flex;
        background: linear-gradient(rgba(255, 255, 255, 0.632), #ffffff58);
      .gTitleLeft{
        .mainT{
        font-size: 30px;
        font-weight: bold;
        color: rgb(118, 78, 13); 
        .grltBeta{
            margin-left: 8px;
            font-size: 15px;
            color: #593320;
            background: #f0e0c2;
            padding: 0 3px;
            border-radius: 0.75rem;
            font-weight: 500;
       }
      }
      .tLogo{
            width: 100px;
            margin-right: 5px;
        }
      }
      .subT{
        font-size: 20px;
        color: rgb(221, 184, 125);
        margin-top: -2px;
      }
      .tLink{
        margin-left: auto;
        margin-right: 30px;
        margin-top: 15px;
        font-size: 15px;
        color: rgb(161, 133, 88);
        .tLogo{
            width: 20px;
            margin-right: 5px;
        }
        .tRef{
            color: rgb(161, 133, 88);
            text-decoration: none;
            font-weight: 500;
            transition: all 0.5s;
            border-radius: 0.75rem;
            &:hover{
                color: rgb(255, 246, 234);
                font-weight: 700;
                background: #593320a4; 
               
            }
        
      }
    }
}
.topWall{
        width: 100%;
        height: 10px;
        background-image: url('@/assets/wallTop.png');
    }

.mainBox{
    height: 800px;
    /*background-image: url('@/assets/background.jpg');*/
    /*background-image: url('@/assets/bgLight.jpg');*/
    background: linear-gradient(rgb(255, 255, 255), #ffffff58);
    background-size: cover ; 
    display: flex;
    justify-content: center;
    align-items: center;
    .gMap{
    width: 75%;
    height: 750px;
    background: #56311f79;
    background-image: url("@/assets/main.png");
    border-radius: 0.75rem;
    backdrop-filter: blur(10px);
    background-size: auto 100%;
    box-shadow: rgba(49, 16, 4, 0.61) 0px 7px 29px 0px;
    .gmMain{
        width: 100%;
        height: 100%;
        background-image: url('@/assets/mapBg.png');
        background-size: 100% 100% ;
        background-position: center;
        background-repeat: no-repeat;
        /*flex-direction: none;*/
        /*flex-wrap: nowrap;*/
       .gmmbSub{
        position: absolute;
       }
        .gmmImg{
        width: 100%;        
       }
       .bossImg{
        width: 60px;
        height: auto;
        background: #ffffff7b;
        border: 0px solid #fff;
        border-radius: 0.75rem;
        transition: all 0.5s;
        font-size:15px;

        .gmmbTips{
            position: relative;
            display: inline-block;
            border-bottom: 1px dotted rgba(0, 0, 0, 0.5); 
            border-radius: 0.75rem;
        }
        .gmmbTips .gmmbTipsText {
                visibility: hidden;
                width: 120px;
                background-color:rgba(0, 0, 0, 0.5);
                border-radius: 0.75rem;
                color: #fff;
                text-align: center;
                padding: 5px 0;
                position: absolute;
                z-index: 1;
                .gmmbtRef{
                    color: rgb(255, 255, 255);
                    text-decoration: none;
                    font-weight: 700;
                }
            }
        .gmmbTips:hover .gmmbTipsText {
                visibility: visible;
            }
        &:hover{
           width:80px;
           height: auto;
           border: 2px solid #fff; 
           box-shadow: rgba(49, 16, 4, 0.845) 0px 7px 29px 0px;}
        &:active{
            background: #fffa657b;
            border: 3px solid #fff1a0;
            box-sizing: border-box;
        }
    }
        .bossImgIn{
        width: 40px;
        height: auto;
        transition: all 0.5s;
    }
    }
}
   .gInfo{
    width: 20%;
    height: 800px;
    margin-left: 25px;
    /*background: #593320a4; */
    justify-content: center;
    align-items: center;
    .gibTop{
        margin-top: 10px;
        margin-left: 5px;
        margin-right: 0px;
        width: 95%;
        height: 75%;
        background: #ffffff00; 
       .gibTopTop {
        height: 10px;
        width: 100%;
        background-image: url('@/assets/wallTop.png');
        .gttTitle{
            height: 360px;
            width: 300px;
            align-items: center;
            text-align: center;
            margin: 20px 10px;

           .gtttText{
               font-size: 23px;
               font-weight: 600;
               color: rgb(255, 255, 255);
            }
          .gtttIcon{
               margin-top: 20px;
               .gtttiImg{
                   width: auto;
                   height: 180px;
                }
            }
          .gtttQuation{
               margin-top:10px;
               font-family:'SimSun', '宋体', serif; ;
               font-style: italic;
               font-size: 14px;
               font-weight: 400;
               color: rgb(221, 184, 125);
            }
           .gtttBasicInfo{
               margin-top: 20px;
               font-size: 14px;
               font-weight: 400;
               color: rgb(255, 226, 196);
            }
          } 
        }
       .gttInfo{
        .gttiBox{
            margin-top: 10px;
            .gttibText{
                flex-direction: column;
                margin-top:30px;
                margin-left: 40px;
                height:150px;
                width:90%;
                align-items: center;
                .gtiSub{display: flex;margin-left: 20px;margin-top: 5px;font-size: 14px;
                    .stastic{
                        border-radius: 0.25rem;
                        background-color: #e7fbff;
                        color: rgb(26, 49, 53);
                        font-weight: 600;
                    }
                    .dynamic{
                        margin-left: 20px;
                        width: 55%;
                        color: rgb(226, 255, 255);
                    }
                }
            }
        }
       }
       .gttLink{
            margin:15px 80px;
            align-items: center;
            display: flex;
            .gttlIcon{
                .tLogo{
                    width: 32px;
                    margin-right: 1px;
                }
            }
            .gttlText{
                .gttltRef{
                color: rgb(161, 133, 88);
                text-decoration: none;
                font-weight: 700;;
                transition: all 0.5s;
                &:hover{
                    color: rgb(255, 246, 234);
                    font-weight: 900;
                    }
                }
            }
       }
       .gibTopBot{
        height: 590px;
        width: auto;
        background-image: url('@/assets/boxBg2.jpg');
        background-size: auto 100% ; 
        background-position: center;
    }
    }
   .gibBot{
        margin-left: 5px;
        margin-right: 0px;
        margin-top: 20px;
        width: 95%;
        height: 18%;
        .gibbBox{
            width: 100%;
            height: 100%;
            background-image: url('@/assets/boxBg.jpg');
            /*border-radius: 0.75rem;*/
            /*backdrop-filter: blur(10px);*/
            .gibbba{
                justify-content: center;
                align-items: center;
                margin:auto;
                display: flex;
                height: 100%;
                width: 100%;
                .gibbbVideo{
                    margin-top:20px;
                    border: 2px solid #fff; 
                    margin:auto;
                    align-items: center;
                    justify-content: center;
                    height:100px;
                    width: auto;
                    background: #e7fbff;
                    transition: all 0.5s;
                    &:hover{
                        height:120px;
                        width: auto;
                        border: 3px solid #fff;
                        box-shadow: rgba(49, 16, 4, 0.845) 0px 7px 29px 0px; 
                    }
                }
            }
          
        }
    }
   }
}
.gClick{
    justify-content: center;
    align-items: center;
    margin:auto;
    width:200px;
    height: 50px;
    .gckBox{
        height: 100%;
        align-items: center;
        justify-content: center; 
        background-image: url('@/assets/boxBg.jpg');
        text-align: center;
        color:#fff;
        font-size:18px;
        font-weight: 700;
    } 
}
.wikiFrame{
    justify-content: center;
    align-items: center;
    margin:auto;
    margin-top:50px;
    width:90%;
    height:500px;
    .wiframe{
        justify-content: center;
        box-shadow: rgba(49, 16, 4, 0.845) 0px 7px 29px 0px;
        border: none;
        border-radius: 0.75rem;
        width:100%;
        height:500px;
    }
}

</style>