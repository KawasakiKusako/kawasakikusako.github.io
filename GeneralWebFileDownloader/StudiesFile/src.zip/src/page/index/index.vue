<template>
    <div>
        
        <div class="bigbox" style="margin: auto;">
            <div class="grass"></div>
            <div class="box1">
                <div class="leftbox">
                    <img  @click="videoshow=true" src="@/assets/2.png"/>
                </div>
                <div class="dialog"  @click="videoshow = false" v-if="videoshow">
                    <video class="video" controls src="@/assets/合集.mp4" />
                </div>
                <div class="rightbox">
                    <div class="title">探索，战斗，建造</div>
                    <div class="message">
                        <div class="s1">
                            在这个世界上，你为生存、财富和荣耀而战，整个世界尽在你指尖。深入幽暗的广阔洞穴，寻找更强大的敌人来测试你的战斗能力，或者建设自己的城市——在《泰拉瑞亚》中，选择权在你手中！
                        </div>
                        <div class="s2">
                            《泰拉瑞亚》将经典动作游戏元素与沙盒风格的创造自由相结合，是一种独特的游戏体验，其中的旅程和目标都和玩家本人一样独特！
                        </div>

                    </div>
                </div>
                
            </div>
        </div>
        <el-carousel 
            class="custom-carousel" 
            :interval="4000" 
            type="card" 
            height="300px"

        >
            <el-carousel-item v-for="item in 6" :key="item">
                <h3 text="2xl" justify="center"></h3>
            </el-carousel-item>
        </el-carousel>
        <div class="bigBox " style="margin-top: 60px;" >
            <div class="box">
                <div class="block"></div>
                <div class="topbox">
                    <div class="pot1">
                        <div class="black"></div>
                    </div>
                    <div class="text1 fs16 mt10"><strong>泰拉瑞亚：爱之劳动现已推出!</strong></div>
                    <div class="text2 fs14">最新的泰拉瑞亚更新今天发布 - 在此处查看所有详细信息！</div>
                </div>
                <!-- 下 -->
                <div class="botbox">
                    <div class="time">九月 27, 2022</div>
                    <router-link to="/new1" class="new">
                        <img class="mt5 ml40 cu" src="@/assets/Y.3.png" />
                        <div class="read cu">Read More</div>
                    </router-link>
                </div>
            </div>
            <div class="box">
                <div class="block"></div>
                <div class="topbox">
                    <div class="pot2">
                        <div class="black"></div>
                    </div>
                    <div class="text1 fs16"><strong>泰拉瑞亚 1.4.3.3 - Steam Deck 优化更新！</strong></div>
                    <div class="text2 fs14">Steam Deck 优化以及适合所有人的一些 QOL/修复！</div>
                </div>
                <!-- 下 -->
                <div class="botbox">
                    <div class="time">二月 25, 2022</div>
                    <router-link to="/new2" class="new">
                        <img class="mt5 ml40 cu" src="@/assets/Y.3.png" />
                        <div class="read cu">Read More</div>
                    </router-link>
                </div>
            </div>
            <div class="box">
                <div class="block"></div>
                <div class="topbox">
                    <div class="pot3">
                        <div class="black"></div>
                    </div>
                    <div class="text1 fs16 mt10"><strong>泰拉瑞亚 x 饥荒一起更新现已推出！</strong></div>
                    <div class="text2 fs14">获取有关有史以来最令人惊叹的跨界更新之一的有趣细节！</div>
                </div>
                <!-- 下 -->
                <div class="botbox">
                    <div class="time">十一月 15, 2021</div>
                    <router-link to="/new3" class="new">
                        <img class="mt5 ml40 cu" src="@/assets/Y.3.png" />
                        <div class="read cu">Read More</div>
                    </router-link>
                </div>
            </div>
        </div>
        <el-backtop :right="100" :bottom="100" />
    </div>
</template>

<script setup>
import {ref,reactive} from "vue"
let videoshow = ref(false);
</script>

<style lang="scss" scoped>
.bigbox{
    width: 970px;
    height: 396px;
    .grass{
    width: 970px;
    height: 8px;
    background-image: url("@/assets/wallTop.png");
    }
.box1{
    background: url("@/assets/boxBg.jpg");
    width: 970px;
    height: 396px;
    display: flex;
    .leftbox{
        flex: 2;
        margin: 20px 20px;
        background-image: url("@/assets/1.png");
        border: 1px solid burlywood;
        border-radius: 8px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        background-size: cover;
        display: flex;
        justify-content: center;
        align-items: center;
        flex-direction: column;
        .videoTextIcon{
        width: 500px;
        }
    }
    .rightbox{
        flex: 1;
        display: flex;
        flex-direction: column;
        .title{
            width: 323.34px;
            height: 35px;
            justify-content: center;
            color: #d6ffe4;
            text-align: center;
            margin-top: 7px;
            font-size: 20px;
        }
        .message{
            margin: 5px 5px;
            margin-right: 20px;
            width: 323.34px;
            height: 361px;
            color: #d6ffe4;
            display: flex;
            flex-direction: column;
            border: 1px solid burlywood;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            .s1{
                flex: 1;
                font-size: 18px;
                text-indent: 2em;
                line-height: 1.8;
                text-align: left
            }
            .s2{
                flex: 1;
                font-size: 18px;
                text-indent: 2em;
                line-height: 1.8;
                text-align: left
            }

        }
    }

    }
}
.dialog{
    position: fixed;
    width: 100%;
    height: 100%;
    background:rgba(0,0,0,0.6);
    top: 0;
    left: 0;
    z-index: 10000;
    display: flex;
    justify-content: center;
    align-items: center;
    .video{
        width: 700px;
    }
}
// jb
.bigBox{
    width: 100%;
    height: 400px;
    display: flex;
    justify-content: center;
    .box{
        width: 300px;
        height: 318px;
        margin: 20px;
        display: flex;
        justify-content: center;
        align-items: center;
        flex-direction: column;
        background-image: url('@/assets/boxBg2.jpg');
        background-size: contain;
        background-repeat: no-repeat;
        background-position: center;
        box-shadow: 1px 1px 10px 1px #000000;
        .block{
            width: 300px;
            height: 10px;
            background-image: url("@/assets/wallTop.png");
            background-size: cover;
        }
        .topbox{
            width: 300px;
            height: 318px;
            display: flex;
            justify-content: center;
            flex-direction: column;
            overflow: hidden;
            background-size: cover;
            .pot1{
                width: 300px;
                height: 180px;
                background-image: url('@/assets/Y.1.png');
                background-size: 265px 200px;
                background-repeat: no-repeat;
                background-position: center;
                display: flex;
                justify-content: center;
                .black{
                    
                    width: 270px;
                    height: 180px;
                    transition: all 0.5s;
                    &:hover{
                        background-color: rgba($color: #000000, $alpha: 0.4);
                    }
                }
            }
            .pot2{
                width: 300px;
                height: 200px;
                margin-top:8px ;
                background-image: url('@/assets/Y.2.png');
                background-size: 265px 200px;
                background-repeat: no-repeat;
                background-position: center;
                display: flex;
                justify-content: center;
                .black{
                    
                    width: 270px;
                    height: 180px;
                    transition: all 0.5s;
                    &:hover{
                        background-color: rgba($color: #000000, $alpha: 0.4);
                    }
                }
            }
            .pot3{
                width: 300px;
                height: 185px;
                background-image: url('@/assets/Y.3.gif');
                background-size: 265px 200px;
                background-repeat: no-repeat;
                background-position: center;
                display: flex;
                justify-content: center;
                .black{
                    
                    width: 270px;
                    height: 180px;
                    transition: all 0.5s;
                    &:hover{
                        background-color: rgba($color: #000000, $alpha: 0.4);
                    }
                }
            }
            .text1{
                color:#d6ffe4;
                text-align: center;
            }
            .text2{
                color: #f6ffe3;
                text-align: center;
            }
        }
        .botbox{
            width: 300px;
            height: 40px;
            display: flex;
            justify-content: center;
            align-items: center;
            .time{
                margin-right:20px;
                color:#d6ffe4;
                display: flex;
                
            }
            .read{
                margin-left:5px;
                color:#d6ffe4;
            }
            .new{
                display: flex;  
            }
        }
    }
}
.custom-carousel {
    width: 1270px; /* 设置你需要的宽度 */
    margin: 0 auto; /* 可选：居中显示 */
    margin-bottom: 50px;
    margin-top:50px ;
}
 
.el-carousel__item h3 {
  color: #475669;
  opacity: 0.75;
  line-height: 200px;
  margin: 0;
  text-align: center;
}
 
.el-carousel__item:nth-child(1) {
    background-color: #99a9bf;
    background-image: url('@/assets/8C63E6124F1BC0B32D645A2CB2999216.webp');
    background-repeat: no-repeat;
    background-position: center;
    background-size: cover;
    border-radius: 30px;
}
 
.el-carousel__item:nth-child(2) {
    background-color: #d3dce6;
    background-image: url('@/assets/74D75378C567B7D90D28498BE0A2C505.jpeg');
    background-repeat: no-repeat;
    background-position: center;
    background-size: cover;
    border-radius: 30px;
}
.el-carousel__item:nth-child(3) {
    background-color: #d3dce6;
    background-image: url('@/assets/F104702B27015BDA553310CED7EBD4DC.jpeg');
    background-repeat: no-repeat;
    background-position: center;
    background-size: cover;
    border-radius: 30px;
}
.el-carousel__item:nth-child(4) {
    background-color: #d3dce6;
    background-image: url('@/assets/B61026F598C6E087110A5A5D40DD491F.jpg');
    background-repeat: no-repeat;
    background-position: center;
    background-size: cover;
    border-radius: 30px;
}
.el-carousel__item:nth-child(5) {
    background-color: #d3dce6;
    background-image: url('@/assets/91EABE1C47F4ABC21FA57B705E81FD30.webp');
    background-repeat: no-repeat;
    background-position: center;
    background-size: cover;
    border-radius: 30px;
}
.el-carousel__item:nth-child(6) {
    background-color: #d3dce6;
    background-image: url('@/assets/55E988C1B6361C352F34F94C43213E8D.webp');
    background-repeat: no-repeat;
    background-position: center;
    background-size: cover;
    border-radius: 30px;
}
</style>
