<template>
    <div class="bigbox">
        <div class="grass">
            <img src="@/assets/wallTop.png" />
        </div>
        <div class="title" style="margin-top: -5px;"> 
            <div class="titlebox1">
                <div class="titletext">
                    <strong>泰拉瑞亚 1.4.3.3 - Steam Deck 优化更新！</strong>
                </div>
            </div>
        </div>
        <div class="middle">
            <div class="img"><img src="@/assets/steamdeck1433.png" width=870px; height=350px;/></div>
            <div class="middletext">泰拉瑞亚玩家们，大家好！</div>
            <div class="middletext">正如我们在过去几个月中提到的，该团队一直在努力进行更新，以进一步优化泰拉瑞亚的 Steam Deck 游戏 - 包括性能和控制。随着 Steam Deck 从今天开始正式向玩家发货，我们很高兴能够及时向所有人推送此更新！对于目前不在 Steam Deck 上玩游戏的泰拉瑞安人，请不要担心，因为我们也为您提供了一些生活质量、平衡和错误修复。事不宜迟，让我们直接开始吧！</div>
            <div class="middletext">请注意，此更新还包括对泰拉瑞亚专用服务器应用程序的更新。您始终可以在 Terraria.org 底部找到最新版本，但我们在下面也为今天的版本提供了一个链接：</div>
            <div class="middletext">泰拉瑞亚专用服务器应用程序 （1.4.3.3）</div>
            <div class="img"><img src="@/assets/divid-0x5fcb50a4aec00000.png" /></div>
            <div class="middletext">泰拉瑞亚 STEAM DECK 控制</div>
            <div class="middletext">除了技术下的引擎盖性能优化等之外，当我们说“为 Steam Deck 优化泰拉瑞亚”时，我们还意味着什么？嗯，一个重点领域是控制。</div>
            <div class="middletext">当我们第一次坐下来在 Steam Deck 上畅玩泰拉瑞亚时，我们立即意识到我们需要进行一些调整才能充分利用这个新系统所提供的一切。除了 Steam Deck 提供的默认触摸控件（我们可能会在未来进行改进）之外，我们还将下面的小图放在一起，向您展示我们如何优化 Steam Deck 上所有可用的控件：</div>
            <div class="img"><img src="@/assets/Render02Comp1920.png" width=870px; height=480px;/></div>
        </div>
        <div class="title" style="margin-top: -5px;"> 
            <div class="titlebox2">
                <div class="bottomtext">
                    <i>最后更新日期：2025/05/15</i>
                </div>
            </div>
        </div>
    </div>
</template>

<script setup>

</script>

<style lang="scss" scoped>
.bigbox{
    width: 970px;
    margin: auto;
    display: flex;
    justify-content: center;
    flex-direction: column;
    .title{
        display: flex;
        justify-content: center;
        flex-direction: column;
        background-image: url('@/assets/title.jpg');
        background-size: cover;
        background-repeat: no-repeat;
        background-position: center;
        .titlebox1{
            color:#d6ffe4;
            font-size: 26px;
            border-bottom: 1.5px solid burlywood;
            .titletext{
                margin-left:30px ;
            }
        }
            
    }
    .middle{
        width: 970px;
        height: 1500px;
        display: flex;
        justify-content: center;
        flex-direction: column;
        background-image: url('@/assets/middle.jpg');
        background-size: cover;
        background-repeat: no-repeat;
        background-position: center;
        .middletext{
            margin-left:50px ;
            color: #f6ffe3;
            margin-bottom:20px ;
            font-size: 20px;
        }
        .img{
            display: flex;
            justify-content: center;
            align-items: center;

        }
    }
    .titlebox2{
        border-top: 1.5px solid burlywood;
        .bottomtext{
                font-size: 20px;
                color:#d6ffe4;
                margin: 10px;
                margin: left 20px; ;
            }
    }
}
</style>