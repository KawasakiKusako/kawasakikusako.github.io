<template>
  <div class="zongti">
      <Header></Header>
      <router-view></router-view>
      <Footer></Footer>
  </div>
</template>

<script setup>
//引入头部和底部的组件
import Header from '@/components/Header.vue'
import Footer from '@/components/Footer.vue'
</script>

<style lang="scss" scoped>
</style>