//main.js
import { createApp } from 'vue'
import './style.css'
import App from './App.vue'
// 引入UI框架
import ElementPlus from 'element-plus'
import 'element-plus/dist/index.css'
//引入路由文件
import router from '@/router/index.js'

// 提取createApp();
let app = createApp(App);

// 提取完以后注入UI框架
app.use(ElementPlus);
//把路由注入到项目中
app.use(router);
app.mount('#app')